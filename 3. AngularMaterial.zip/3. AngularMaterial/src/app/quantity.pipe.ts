import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name: 'qty'
})
export class QuantityPipe implements PipeTransform {
    transform(inputValue: number, quantityText: string) {
        if (inputValue === 0) {
            return 'Out Of Stock !'
        }
        return inputValue + " " + quantityText;
    }
}