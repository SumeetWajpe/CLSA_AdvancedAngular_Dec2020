import { Product } from './product.model';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn:'root'
})
export class ProductAPIService {
    products:Product[]=[];
   constructor(public httpClientObj:HttpClient){

   }

    GetAllProducts() {
        return this.httpClientObj.get<Product[]>('http://localhost:5000/products').toPromise()
    }

    DeleteAProduct(theId:number){
        return this.httpClientObj.post<Product[]>('http://localhost:5000/products/'+theId,null).toPromise();
    }
    
}