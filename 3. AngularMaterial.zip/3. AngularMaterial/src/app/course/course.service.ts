export class CourseService{
    courses:string[] = ["React","Angular","Typescript"]
    
    AddANewCourse(courseName:string){
        this.courses.push(courseName);
    }
}