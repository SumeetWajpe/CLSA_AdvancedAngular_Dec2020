import { Component, OnInit } from '@angular/core';
import { PostsService } from './posts.service';
import { Observable } from 'rxjs';
import { Post } from './post.model';

@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.css']
})
export class PostsComponent implements OnInit {

  allPosts:Post[];
  constructor(public postServObj:PostsService) { }

  ngOnInit() {
    // Using Observables
  //  let observablePosts = this.postServObj.getAllPosts();
  //  observablePosts.subscribe((response)=>{
  //    this.allPosts = response;
  //  });

  // Using Promise
  let aPromise = this.postServObj.getAllPosts();
  aPromise.then(
    (response)=>this.allPosts = response,
    (err)=>console.log(err)
  )
  }

}
