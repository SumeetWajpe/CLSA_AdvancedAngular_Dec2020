import { Component, Input, OnInit,EventEmitter, Output } from '@angular/core';


@Component({
  selector: 'course-card',
  templateUrl: './course-card.component.html',
  styleUrls: ['./course-card.component.css']
})
export class CourseCardComponent implements OnInit {

  @Input() course;
  @Output() courseselected = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }

  OnClickHandler(){
    // emit
    this.courseselected.emit();
  }

}
