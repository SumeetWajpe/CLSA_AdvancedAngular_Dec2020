import { Component, ContentChild, ElementRef, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { CourseCardComponent } from './course-card/course-card.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'viewchild';
  courses=[
    {id:1,title:'Angular Core',description:'This course is a Deep Dive in Angular core features of Angular 10.',iconUrl:'https://sdtimes.com/wp-content/uploads/2018/02/Angular_full_color_logo.svg_.png'},
    {id:2,title:'Angular Material',description:'This course is a Deep Dive in Angular core features of Angular material',iconUrl:'https://kenoleon.github.io/Front-End-Web-Dev-UI-UX/assets/images/AngularMaterial.jpg'},
  ];


  constructor(){
    //console.log('(Ctor)Card ->' , this.card);
  }

  ngAfterViewInit(){
    //console.log('(AfterViewInit)Card ->' , this.card);
  } 
 
// @ViewChildren(CourseCardComponent,{read:ElementRef})
// cards:QueryList<ElementRef>;

  // @ViewChild(CourseCardComponent)
  // card:CourseCardComponent;

  // @ViewChild('course1')
  // card1:CourseCardComponent;

  // @ViewChild('course2')
  // card2:CourseCardComponent;

  //  @ViewChild('containerDiv')
  // containerDiv:ElementRef;


  //   @ViewChild('course1',{read:ElementRef})
  // card1:ElementRef;

  OnSelectedHandler(){
    //console.log('Card ->' , this.card);
   // console.log('Card ->' , this.card2);
    // console.log(this.containerDiv.nativeElement);
    //console.log('cards : ',this.cards)    
  }

}
