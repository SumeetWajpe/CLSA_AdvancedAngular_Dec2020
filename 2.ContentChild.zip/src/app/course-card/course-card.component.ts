import { Component, Input, OnInit,EventEmitter, Output, ContentChild, ElementRef } from '@angular/core';


@Component({
  selector: 'course-card',
  templateUrl: './course-card.component.html',
  styleUrls: ['./course-card.component.css']
})
export class CourseCardComponent implements OnInit {

  @Input() course:string;
  @Output() courseselected = new EventEmitter();
  constructor() { }

  @ContentChild('imageElement')
  imageEl:ElementRef;

  ngOnInit(): void {
  }
  ngAfterContentInit(){
    console.log('(ngAfterContentInit)Image ->' , this.imageEl);
  }

  OnClickHandler(){
    // emit
    this.courseselected.emit();
  }

}
