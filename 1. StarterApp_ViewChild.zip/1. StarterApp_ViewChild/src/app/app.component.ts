import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'viewchild';
  courses=[
    {id:1,title:'Angular Core',description:'This course is a Deep Dive in Angular core features of Angular 10.',iconUrl:'https://sdtimes.com/wp-content/uploads/2018/02/Angular_full_color_logo.svg_.png'},
    {id:2,title:'Angular Material',description:'This course is a Deep Dive in Angular core features of Angular material',iconUrl:'https://kenoleon.github.io/Front-End-Web-Dev-UI-UX/assets/images/AngularMaterial.jpg'},
  ]
}
